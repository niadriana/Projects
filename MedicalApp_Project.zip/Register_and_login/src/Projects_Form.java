import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class Projects_Form extends JFrame {
    private JTextField tfEmail;
    private JButton btnSearchEmail;
    private JComboBox cbProjects;
    private JButton btnCancel;
    private JButton btnConfirm;
    private JPanel ProjectsPanel;
    private JButton btnDelete;

    public Projects_Form() {
        //parametry dla wyświetlanego okna zgody na badania i projekt badawczy
        setTitle("Projects Panel");
        setContentPane(ProjectsPanel);
        setMinimumSize(new Dimension(1077, 250));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setVisible(true);

        btnSearchEmail.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String email = tfEmail.getText();
                buttonEnable(email);
            }
        });
        btnCancel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                //Profile_Form profileForm = new Profile_Form();
            }
        });
        btnConfirm.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //String project = cbProjects.getSelectedItem().toString();
                String projects = cbProjects.getSelectedItem().toString();
                String email = tfEmail.getText();
                addingProjects(projects, email);
                //addingProjects(projects,email);
                setVisible(false);
                //Profile_Form profileForm = new Profile_Form();
            }
        });

        btnDelete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String email = tfEmail.getText();
                delete(email);
                setVisible(false);
            }
        });
    }
    private void delete(String email){
        final String DB_URL = "jdbc:mysql://localhost:3306/niadriana";
        final String USERNAME = "root";
        final String PASSWORD = "";
        try {
            //sql oraz zmienne które są wymagane
            Connection connection = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            String sql = "UPDATE users SET projects=NULL, commissionedresearch=NULL, researchresults=NULL, timeofresearch=NULL WHERE email=?";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, email);
            int addedRows = preparedStatement.executeUpdate();
            if (addedRows > 0){
                preparedStatement.execute();
                JOptionPane.showMessageDialog(this, "Project deleted correctly",
                        "Congrate", JOptionPane.INFORMATION_MESSAGE);
                }
            } catch(Exception e){
            e.printStackTrace();
        }
    }

    private void addingProjects(String projects, String email){
        final String DB_URL = "jdbc:mysql://localhost:3306/niadriana";
        final String USERNAME = "root";
        final String PASSWORD = "";
        try {
            //sql oraz zmienne które są wymagane
            Connection connection = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            String sql = "UPDATE users SET projects=? WHERE email=?";
            //PreparedStatement preparedStatement = connection.prepareStatement(sql);
            //preparedStatement.setString(1, projects);
            //preparedStatement.setString(2, email);
            //sprawdzenie zgody na projekt badawczy
            User user = consentcheck(email);
            //int addedRows = preparedStatement.executeUpdate();
            if(user != null && user.consent.equals("NO")){
                //preparedStatement.execute();
                JOptionPane.showMessageDialog(this, "Sorry, but first you need to add consent",
                        "Unfortunatelly", JOptionPane.INFORMATION_MESSAGE);
                } else {
                PreparedStatement preparedStatement = connection.prepareStatement(sql);
                preparedStatement.setString(1, projects);
                preparedStatement.setString(2, email);
                int addedRows = preparedStatement.executeUpdate();
            if (addedRows > 0){
                preparedStatement.execute();
                JOptionPane.showMessageDialog(this, "Project added correctly",
                        "Congrate", JOptionPane.INFORMATION_MESSAGE);
            }
        }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    public User user;
    private User consentcheck(String email) {
        User user = null;
        final String DB_URL = "jdbc:mysql://localhost:3306/niadriana";
        final String USERNAME = "root";
        final String PASSWORD = "";
        try {
            //połączenie z bazą danych
            Connection connection = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            Statement statement = connection.createStatement();
            String sql = "SELECT consent FROM users WHERE email=?";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, tfEmail.getText());
            ResultSet resultSet = preparedStatement.executeQuery();
            if(resultSet.next()) {
                user = new User();
                //dane które uzyskamy
                user.consent = resultSet.getString("consent");
            }
            statement.close();
            connection.close();
        }
        catch(Exception e) {
            e.printStackTrace();
        }
        return user;
    }

    private void buttonEnable (String email){
        final String DB_URL = "jdbc:mysql://localhost:3306/niadriana";
        final String USERNAME = "root";
        final String PASSWORD = "";
        try {
            //połączenie z bazą danych
            Connection connection = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            Statement statement = connection.createStatement();
            String sql = "SELECT * FROM users WHERE email=?";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, tfEmail.getText());
            ResultSet resultSet = preparedStatement.executeQuery();
            //to co uzyskamy
            if (resultSet.next()) {
                btnCancel.setEnabled(true);
                btnConfirm.setEnabled(true);
                btnDelete.setEnabled(true);
            } else {
                JOptionPane.showMessageDialog(this, "Email for searching is wrong, please enter correct email",
                        "Try one more time", JOptionPane.ERROR_MESSAGE);
            }
            statement.close();
            connection.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        Projects_Form projects_form = new Projects_Form();
    }
}
