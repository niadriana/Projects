import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class Profile_Form extends JFrame {
    private JButton btnResearchConsent;
    private JButton btnProjects;
    private JButton btnCommissionedResearch;
    private JPanel ProfilePanel;
    private JTextField tfEmailSearch;
    private JTextField tfDate;
    private JButton btnEdit;
    private JButton btnSave;
    private JButton btnSearch;
    private JTextField tfName;
    private JTextField tfSurname;
    private JTextField tfEmail;
    private JTextField tfPhone;
    private JTextField tfAddress;
    private JTextField tfGender;
    private JTextField tfNationality;
    private JTextField tfPESEL;
    private JButton researchResultsButton;
    private JButton btnDelete;

    public Profile_Form() {
        //parametry dla okna
        setTitle("Profile Panel");
        setContentPane(ProfilePanel);
        setMinimumSize(new Dimension(1027, 300));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setVisible(true);
        Calender();
        //connectToDatabase();

        btnResearchConsent.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Research_Consent_Form researchConsentForm = new Research_Consent_Form();
            }
        });
        btnProjects.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Projects_Form projectsForm = new Projects_Form();
            }
        });
        btnCommissionedResearch.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CommissionedResearch_Form commissionedResearch = new CommissionedResearch_Form();

            }
        });
        User user;
        User update;
        btnSearch.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String email = tfEmail.getText();
                searchemail(email);
            }
        });
        btnEdit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tfPhone.setEditable(true);
                tfAddress.setEditable(true);
                tfGender.setEditable(true);
                tfNationality.setEditable(true);
                tfPESEL.setEditable(true);
            }
        });
        btnSave.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String email = tfEmailSearch.getText();
                String phone = tfPhone.getText();
                String address = tfAddress.getText();
                String gender = tfGender.getText();
                String nationality = tfNationality.getText();
                String PESEL = tfPESEL.getText();
                update(email, phone, address, gender, nationality, PESEL);
            }
        });
        btnDelete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String email = tfEmailSearch.getText();
                if(!tfEmailSearch.getText().isEmpty()){
                    final String DB_URL = "jdbc:mysql://localhost:3306/niadriana";
                    final String USERNAME = "root";
                    final String PASSWORD = "";
                    try {
                        //sql oraz zmienne które są wymagane
                        Connection connection = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
                        String sql = "DELETE FROM users WHERE email=?";
                        PreparedStatement preparedStatement = connection.prepareStatement(sql);
                        preparedStatement.setString(1,email);
                        int addedRows = preparedStatement.executeUpdate();
                        if (addedRows > 0){
                            preparedStatement.execute();
                            JOptionPane.showMessageDialog(Profile_Form.this, "Profile deleted correctly",
                                    "Congrate", JOptionPane.INFORMATION_MESSAGE);
                            dispose();
                        }}catch(Exception ce){
                        ce.printStackTrace();
                        }
                }else{
                        JOptionPane.showMessageDialog(Profile_Form.this, "There is no account for this email",
                                "Try one more time", JOptionPane.ERROR_MESSAGE);
                    }
            }
        });
        researchResultsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ResearchResults_Form researchResultsForm = new ResearchResults_Form();
            }
        });
    }

    private User update(String email, String phone, String address, String gender, String nationality, String PESEL) {
        final String DB_URL = "jdbc:mysql://localhost:3306/niadriana";
        final String USERNAME = "root";
        final String PASSWORD = "";
        try {
            //sql oraz zmienne które są wymagane
            Connection connection = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            String sql = "UPDATE users SET phone=?, address=?, gender=?, nationality=?, PESEL=? WHERE email=?";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1,phone);
            preparedStatement.setString(2,address);
            preparedStatement.setString(3,gender);
            preparedStatement.setString(4,nationality);
            preparedStatement.setString(5,PESEL);
            preparedStatement.setString(6,email);
            int addedRows = preparedStatement.executeUpdate();
            if (addedRows > 0) {
                preparedStatement.execute();
                JOptionPane.showMessageDialog(Profile_Form.this, "Profile update complete",
                        "Congrate", JOptionPane.INFORMATION_MESSAGE);

            }
        } catch(Exception xe){
            xe.printStackTrace();
        }
        tfPhone.setEditable(false);
        tfAddress.setEditable(false);
        tfGender.setEditable(false);
        tfNationality.setEditable(false);
        tfPESEL.setEditable(false);
        return null;
    }

    private User searchemail(String email) {
        final String DB_URL = "jdbc:mysql://localhost:3306/niadriana";
        final String USERNAME = "root";
        final String PASSWORD = "";
        try {
            //połączenie z bazą danych
            Connection connection = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            Statement statement = connection.createStatement();
            String sql = "SELECT * FROM users WHERE email=?";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, tfEmailSearch.getText());
            ResultSet resultSet = preparedStatement.executeQuery();
            //dane które uzyskamy
            if (resultSet.next()) {
                String add1 = resultSet.getString("name");
                tfName.setText(add1);
                String add2 = resultSet.getString("surname");
                tfSurname.setText(add2);
                String add3 = resultSet.getString("email");
                tfEmail.setText(add3);
                String add4 = resultSet.getString("phone");
                tfPhone.setText(add4);
                String add5 = resultSet.getString("address");
                tfAddress.setText(add5);
                String add6 = resultSet.getString("gender");
                tfGender.setText(add6);
                String add7 = resultSet.getString("nationality");
                tfNationality.setText(add7);
                String add8 = resultSet.getString("PESEL");
                tfPESEL.setText(add8);
                btnEdit.setEnabled(true);
                btnSave.setEnabled(true);
            }
            else{
                JOptionPane.showMessageDialog(this, "Email for searching is wrong, please enter correct email",
                        "Try one more time", JOptionPane.ERROR_MESSAGE);
            }
            statement.close();
            connection.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    /*private boolean connectToDatabase() {
        boolean ResearchConsentVariable = false;
        final String DB_URL = "jdbc:mysql://localhost:3306/niadriana";
        final String USERNAME = "root";
        final String PASSWORD = "";
        try {
            //połączenie z bazą danych i utworzenie tabeli, gdyby nie było
            Connection connection = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            String sql = "CREATE TABLE IF NOT EXISTS users ("
                    + "id INT (10) NOT NULL PRIMARY KEY AUTO_INCREMENT, "
                    + "consent VARCHAR (200) NOT NULL, "
                    + "project VARCHAR(200) NOT NULL, "
                    + "commissionresearch VARCHAR(200) NOT NULL, "
                    + ")";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.executeUpdate(sql);
            //sprawdzenie, czy już jest ktoś w bazie osób zarejestrowanych
            ResultSet resultSet = preparedStatement.executeQuery("SELECT COUNT(*) FROM research");
            if(resultSet.next()) {
                int numUsers = resultSet.getInt(1);
                if(numUsers > 0) {
                    ResearchConsentVariable = true;
                }
            }
            preparedStatement.close();
            connection.close();
        }
        catch(Exception e) {
            e.printStackTrace();
        }
        return ResearchConsentVariable;
    }*/

    public void Calender() {
        Calendar calendar = new GregorianCalendar();
        int month = calendar.get(Calendar.MONTH);
        int year = calendar.get(Calendar.YEAR);
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        tfDate.setText(+day+"."+(month+1)+"."+year);
    }
    public static void main(String[] args) {
        Profile_Form myProfile = new Profile_Form();
    }
}

