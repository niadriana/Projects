import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class ResearchResults_Form extends JFrame{
    private JTextField tfEmailSearch;
    private JButton btnSearch;
    private JTextField tfCommissionedResearch;
    private JButton btnCancel;
    private JButton btnSave;
    private JButton btnDelete;
    private JButton btnEdit;
    private JTextArea tAResults;
    private JPanel ResearchResultsPanel;
    private JTextField tfTimeofResearch;

    public ResearchResults_Form(){
        //parametry dla okna
        setTitle("Research Results Panel");
        setContentPane(ResearchResultsPanel);
        setMinimumSize(new Dimension(807, 370));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setVisible(true);

        btnSearch.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String email = tfEmailSearch.getText();
                searchemail(email);
            }
        });
        btnEdit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tAResults.setEditable(true);
            }
        });
        btnSave.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String researchresults = tAResults.getText();
                String email = tfEmailSearch.getText();
                update(researchresults,email);
            }
        });
        btnDelete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String email = tfEmailSearch.getText();
                final String DB_URL = "jdbc:mysql://localhost:3306/niadriana";
                final String USERNAME = "root";
                final String PASSWORD = "";
                try {
                    //sql oraz zmienne które są wymagane
                    Connection connection = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
                    String sql = "UPDATE users SET researchresults=NULL WHERE email=?";
                    PreparedStatement preparedStatement = connection.prepareStatement(sql);
                    preparedStatement.setString(1, email);
                    int addedRows = preparedStatement.executeUpdate();
                    if (addedRows > 0){
                        preparedStatement.execute();
                        JOptionPane.showMessageDialog(ResearchResults_Form.this, "Research results deleted correctly",
                                "Congrate", JOptionPane.INFORMATION_MESSAGE);
                    }
                } catch(Exception te){
                    te.printStackTrace();
                }
                setVisible(false);
            }
        });
        btnCancel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
    }

    private User searchemail(String email) {
        final String DB_URL = "jdbc:mysql://localhost:3306/niadriana";
        final String USERNAME = "root";
        final String PASSWORD = "";
        try {
            //połączenie z bazą danych
            Connection connection = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            Statement statement = connection.createStatement();
            String sql = "SELECT * FROM users WHERE email=?";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, tfEmailSearch.getText());
            ResultSet resultSet = preparedStatement.executeQuery();
            //dane które uzyskamy
            if (resultSet.next()) {
                String add1 = resultSet.getString("commissionedresearch");
                tfCommissionedResearch.setText(add1);
                String add2 = resultSet.getString("researchresults");
                tAResults.setText(add2);
                String add3 = resultSet.getString("timeofresearch");
                tfTimeofResearch.setText(add3);
                btnEdit.setEnabled(true);
                btnSave.setEnabled(true);
                btnDelete.setEnabled(true);
            }
            else{
                JOptionPane.showMessageDialog(this, "Email for searching is wrong, please enter correct email",
                        "Try one more time", JOptionPane.ERROR_MESSAGE);
            }
            statement.close();
            connection.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    private User update(String researchresults, String email) {
        final String DB_URL = "jdbc:mysql://localhost:3306/niadriana";
        final String USERNAME = "root";
        final String PASSWORD = "";
        try {
            //sql oraz zmienne które są wymagane
            Connection connection = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            String sql = "UPDATE users SET researchresults=? WHERE email=?";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1,researchresults);
            preparedStatement.setString(2,email);
            int addedRows = preparedStatement.executeUpdate();
            if (addedRows > 0) {
                preparedStatement.execute();
                JOptionPane.showMessageDialog(this, "Research results update complete",
                        "Congrate", JOptionPane.INFORMATION_MESSAGE);

            }
        } catch(Exception xe){
            xe.printStackTrace();
        }
        tAResults.setEditable(false);
        return null;
    }

    public static void main(String[] args){
        ResearchResults_Form researchResultsForm = new ResearchResults_Form();
    }
}
