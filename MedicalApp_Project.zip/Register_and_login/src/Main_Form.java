import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Main_Form extends JFrame{
    private JButton btnLogin;
    private JButton btnRegister;
    private JPanel MainPanel;

    public Main_Form(){
        //parametry dla okna
        setTitle("Main Panel");
        setContentPane(MainPanel);
        setMinimumSize(new Dimension(527, 130));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setVisible(true);
        connectToDatabase();
        btnRegister.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                Registration_Form registration_form = new Registration_Form(Main_Form.this);
                User user = registration_form.user;
                if(user != null) {
                    System.out.println("Succesful registration for user: " + user.name);
                }
                else {
                    System.out.println("Registration canceled");
                }
            }
        });
        btnLogin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                Login_Form login_form = new Login_Form(Main_Form.this);
                User user = login_form.user;
                if(user != null) {
                    System.out.println("Succesful login for user: " + user.name);
                }
                else {
                    System.out.println("Logging canceled");
                }
            }
        });
    }

    private boolean connectToDatabase() {
        boolean hasRegistredUsers = false;
        final String MYSQL_SERVER_URL = "jdbc:mysql://localhost:3306/";
        final String DB_URL = "jdbc:mysql://localhost:3306/niadriana";
        final String USERNAME = "root";
        final String PASSWORD = "";
        //połączenie do MYSQLserver i stworzenie bazy danych (gdyby nie było)
        try {
            Connection connection = DriverManager.getConnection(MYSQL_SERVER_URL, USERNAME, PASSWORD);
            Statement statement = connection.createStatement();
            statement.executeUpdate("CREATE DATABASE IF NOT EXISTS niadriana");
            statement.close();
            connection.close();
            //połączenie z bazą danych i utworzenie tabeli, gdyby nie było
            connection = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            statement = connection.createStatement();
            String sql = "CREATE TABLE IF NOT EXISTS users ("
                    + "id INT (10) NOT NULL PRIMARY KEY AUTO_INCREMENT, "
                    + "name VARCHAR (200) NOT NULL, "
                    + "surname VARCHAR(200) NOT NULL, "
                    + "email VARCHAR(200) NOT NULL UNIQUE, "
                    + "phone VARCHAR(200),"
                    + "address VARCHAR(200),"
                    + "gender VARCHAR(200) NULL,"
                    + "nationality VARCHAR(200) NULL,"
                    + "PESEL VARCHAR(200) NULL,"
                    + "password VARCHAR(200) NOT NULL,"
                    + "consent VARCHAR(200) NULL,"
                    + "projects VARCHAR(200) NULL,"
                    + "commissionedresearch VARCHAR(400) NULL,"
                    + "researchresults VARCHAR(1000) NULL,"
                    + "timeofresearch VARCHAR(200) NULL"
                    + ")";
            statement.executeUpdate(sql);
            //sprawdzenie, czy już jest ktoś w bazie osób zarejestrowanych
            statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT COUNT(*) FROM users");
            if(resultSet.next()) {
                int numUsers = resultSet.getInt(1);
                if(numUsers > 0) {
                    hasRegistredUsers = true;
                }
            }
            statement.close();
            connection.close();
        }
        catch(Exception e) {
            e.printStackTrace();
        }
        return hasRegistredUsers;
    }

public static void main(String[] args) {
    Main_Form myMainPanel = new Main_Form();
    }
}
