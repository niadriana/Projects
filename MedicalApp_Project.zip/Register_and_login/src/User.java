public class User {
    //zmienne są publiczne ponieważ będą używane poza klasą Users
    public String name;
    public String surname;
    public String email;
    public String phone;
    public String address;
    public String password;
    public String consent;
    public String project = null;
    public String gender = null;
    public String nationality = null;
    public String PESEL = null;
    public String commissionedresearch = null;
    public String researchresults = null;
    public String timeofresearch = null;

}
