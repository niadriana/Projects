import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class Login_Form extends JDialog {
    private JTextField tfEmail;
    private JPasswordField pfPassword;
    private JButton btnOk;
    private JButton btnCancel;
    private JPanel LoginPanel;

    public Login_Form(JFrame parent){
        //parametry dla okna
        super(parent);
        setTitle("Login");
        setContentPane(LoginPanel);
        setMinimumSize(new Dimension(527, 300));
        setModal(true);
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        //aktywne przyciski
        btnOk.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //sprawdzenie wypełnienia okien
                String email = tfEmail.getText();
                String password = String.valueOf(pfPassword.getPassword());
                //sprawdzenie poprawności wpisanych danych poprzez wywołanie metody
                //jeżeli user będzie wpisany poprawnie, to ok, jeżeli nie wyświetli się błąd
                user = getAuthenticatedUser(email, password);
                if(user != null) {
                    setVisible(false);
                    Profile_Form profileForm = new Profile_Form();
                }
                else {
                    JOptionPane.showMessageDialog(Login_Form.this, "Email or Password invalid",
                            "Try one more time", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        btnCancel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        setVisible(true);
    }
    //sprawdzenie, czy User jest w bazie dancyh, jeżeli nie, to zwróci null
    public User user;
    private User getAuthenticatedUser(String email, String password) {
        User user = null;
        //połączenie z bazami danych
        final String DB_URL = "jdbc:mysql://localhost:3306/niadriana";
        final String USERNAME = "root";
        final String PASSWORD = "";

        try{
            Connection connection = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            Statement statement = connection.createStatement();
            //próba znalezienia danych w tabeli, która wymaga dwóch parametrów podanych poniżej
            String sql = "SELECT * FROM users WHERE email=? AND password=?";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, email);
            preparedStatement.setString(2,password);

            ResultSet resultSet  = preparedStatement.executeQuery();
            if(resultSet.next()) {
                user = new User();
                //dane które uzyskamy
                user.name = resultSet.getString("name");
                user.surname = resultSet.getString("surname");
                user.email = resultSet.getString("email");
                user.phone = resultSet.getString("phone");
                user.address = resultSet.getString("address");
                user.password = resultSet.getString("password");
            }
            statement.close();
            connection.close();
        }
        catch(Exception e) {
            e.printStackTrace();
        }
        return user;
    }

    public static void main(String[] args) {
        Login_Form myLogin = new Login_Form(null);
        User user = myLogin.user;
        if(user != null) {
            System.out.println("Succesful login for user: " + user.name);
        }
        else {
            System.out.println("Logging canceled");
        }
    }
}
