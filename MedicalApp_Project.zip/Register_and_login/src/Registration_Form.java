import com.sun.tools.javac.Main;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;


public class Registration_Form extends JDialog {
    private JTextField tfName;
    private JTextField tfSurname;
    private JTextField tfEmail;
    private JTextField tfPhone;
    private JTextField tfAddress;
    private JPasswordField pfPassword;
    private JPasswordField pfConfirmPassword;
    private JButton btnRegister;
    private JButton btnCancel;
    private JPanel RegisterPanel;

    public Registration_Form(JFrame parent) {
        //parametry dla wyświetlanego okna rejestracji
        super(parent);
        setTitle(" New account");
        setContentPane(RegisterPanel);
        setMinimumSize(new Dimension(527,320));
        setModal(true);
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        //stworzenie aktywnych przycisków
        btnRegister.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                registerUser();
                if(user != null) {
                    Login_Form login_form = new Login_Form(null);
                    User user = login_form.user;
                }
            }
        });
        btnCancel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose(); //gaszenie okna
            }
        });
        setVisible(true);
    }
    private void registerUser() {
    //sprawdzenie czy okna są wypełnione
        String name = tfName.getText();
        String surname = tfSurname.getText();
        String email = tfEmail.getText();
        String phone = tfPhone.getText();
        String address = tfAddress.getText();
        String password = String.valueOf(pfPassword.getPassword());
        String confirmpassword = String.valueOf(pfConfirmPassword.getPassword());
        //wiadomość o błędzie jeżeli chociaż jedno z okien będzie puste
        if(name.isEmpty() || surname.isEmpty() || email.isEmpty() ||
           phone.isEmpty() || address.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this,"Some files are empty",
            "Try one more time", JOptionPane.ERROR_MESSAGE);
            return;
        }
        //sprawdzenie czy hasła są takie same
        if(!password.equals(confirmpassword)) {
            JOptionPane.showMessageDialog(this,"Passwords are not the same",
            "Try one more time", JOptionPane.ERROR_MESSAGE);
            return;
        }
        //dodawanie użytkownika do bazy danych
        user = addUserToDatabase(name, surname, email, phone, address, password);
        if(user !=null){
            dispose();
        }
        else {
            JOptionPane.showMessageDialog(this,"Registration proces is failed",
            "Try one more time", JOptionPane.ERROR_MESSAGE);
        }
   }
   public User user;
   private User addUserToDatabase(String name, String surname,
                                  String email, String phone,
                                  String address, String password) {
        User user = null;
        final String DB_URL = "jdbc:mysql://localhost:3306/niadriana";
        final String USERNAME = "root";
        final String PASSWORD = "";
        try {
        //sql oraz zmienne które są wymagane
            Connection connection = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            Statement statement = connection.createStatement();
            String sql = "INSERT INTO users (name, surname, email, phone, address, password)" + "VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, name);
            preparedStatement.setString(2, surname);
            preparedStatement.setString(3, email);
            preparedStatement.setString(4, phone);
            preparedStatement.setString(5, address);
            preparedStatement.setString(6, password);
        //dodawanie wiersza do tabeli z danymi
            int addedRows = preparedStatement.executeUpdate();
            if (addedRows > 0) {
                user = new User();
                user.name = name;
                user.surname = surname;
                user.email = email;
                user.phone = phone;
                user.address = address;
                user.password = password;
            }
            statement.close();
            connection.close();
        }
        catch(Exception e) {
            e.printStackTrace();
       }
        return user;
   }

    public static void main(String[] args) {
        Registration_Form myRegistration = new Registration_Form(null);
        User user = myRegistration.user;
        }
   }
