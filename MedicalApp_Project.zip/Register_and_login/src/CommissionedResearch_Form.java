import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class CommissionedResearch_Form extends JFrame{
    private JCheckBox cbVitaminD;
    private JCheckBox cbInsulin;
    private JCheckBox cbLungUltrasound;
    private JCheckBox cbBloodPressure;
    private JCheckBox cbVitaminB12;
    private JCheckBox cbThyroid;
    private JCheckBox cbLungXray;
    private JCheckBox cbHolter;
    private JButton btnConfirm;
    private JButton btnCancel;
    private JCheckBox cbGlucose;
    private JCheckBox cbECG;
    private JCheckBox cbUrinalysis;
    private JCheckBox cbStressTest;
    private JTextField tfEmail;
    private JButton btnSearch;
    private JTextField tfProject;
    private JPanel CommissionedResearchPanel;
    private JTextField tfDate;
    private JTextField tfTime;

    //JDateChooser dateChooser = new JDateChooser();
    public CommissionedResearch_Form(){
        //parametry dla okna
        setTitle("Commissioned Research Panel");
        setContentPane(CommissionedResearchPanel);
        setMinimumSize(new Dimension(977, 350));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setVisible(true);
        // aktualna data ustawiona
        Calender();
        //data do wyboru dnia wykonanai badań lekarskich
        //dateChooser.setDateFormatString("dd/MM/YYYY");
        //jpChooseDate.add(dateChooser);

        btnSearch.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String email = tfEmail.getText();
                User user = searchemail(email);
            }
        });
        /*tfEmail.getDocument().addDocumentListener((new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                updateButton();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                updateButton();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                updateButton();
            }
        }));*/
        btnCancel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
            }
        });
        btnConfirm.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int daystoadd = 0;
                try{
                    daystoadd = Integer.parseInt(tfTime.getText());
                }catch(NumberFormatException d){
                    d.printStackTrace();
                    return;
                }
                LocalDate today = LocalDate.now();
                LocalDate timeofresearch = today.plusDays(daystoadd);
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyy");
                String VitaminD = "";
                if (cbVitaminD.isSelected()) VitaminD = "VitaminD";
                String VitaminB12 = "";
                if (cbVitaminB12.isSelected()) VitaminB12 = "VitaminB12";
                String Glucose = "";
                if (cbGlucose.isSelected()) Glucose = "Glucose";
                String Insulin = "";
                if (cbInsulin.isSelected()) Insulin = "Insulin";
                String Thyroid = "";
                if (cbThyroid.isSelected()) Thyroid = "Thyroid";
                String LungUltrasound = "";
                if (cbLungUltrasound.isSelected()) LungUltrasound = "LungUltrasound";
                String ECG = "";
                if (cbECG.isSelected()) ECG = "ECG";
                String LungXray = "";
                if (cbLungXray.isSelected()) LungXray = "LungXray";
                String Urinalysis = "";
                if (cbUrinalysis.isSelected()) Urinalysis = "Urinalysis";
                String BloodPressure = "";
                if (cbBloodPressure.isSelected()) BloodPressure = "BloodPressure";
                String Holter = "";
                if (cbHolter.isSelected()) Holter = "Holter";
                String StressTest = "";
                if (cbStressTest.isSelected()) StressTest = "StressTest";
                String email = tfEmail.getText();
                String project = tfProject.getText();
                String commissionedresearch = null;
                commissionedresearch(VitaminD, VitaminB12, Glucose, Insulin, Thyroid, LungUltrasound, ECG,
                        LungXray, Urinalysis, BloodPressure, Holter, StressTest, email, project, commissionedresearch, String.valueOf(formatter.format(timeofresearch)));
                setVisible(false);
            }
        });
    }
    private void commissionedresearch(String VitaminD, String VitaminB12, String Glucose, String Insulin, String Thyroid, String LungUltrasound,
                                        String ECG, String LungXray, String Urinalysis, String BloodPressure, String Holter, String Stresstest,
                                      String email, String project, String commissionedresearch, String timeofresearch){
        final String DB_URL = "jdbc:mysql://localhost:3306/niadriana";
        final String USERNAME = "root";
        final String PASSWORD = "";
        try {
            //sql oraz zmienne które są wymagane
            Connection connection = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            String sql = "UPDATE users SET commissionedresearch=?, timeofresearch=? WHERE email=?";
            commissionedresearch=null;
                //sql oraz zmienne które są wymagane
                if (project.equals("Allergy")) {
                    //preparedStatement.execute();
                    commissionedresearch = (String) VitaminD + " " + VitaminB12 + " " + Glucose + " " + Insulin + " " + Urinalysis + " " + BloodPressure;
                    if (!cbVitaminB12.isSelected() && !cbVitaminD.isSelected() && !cbGlucose.isSelected() && !cbInsulin.isSelected() && !cbUrinalysis.isSelected() && !cbBloodPressure.isSelected()) {
                        JOptionPane.showMessageDialog(this, "Sorry, but first you need choose any of commissioned research",
                                "Unfortunately", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        PreparedStatement preparedStatement = connection.prepareStatement(sql);
                        preparedStatement.setString(1, commissionedresearch);
                        preparedStatement.setString(2, timeofresearch);
                        preparedStatement.setString(3, email);
                        int addedRows = preparedStatement.executeUpdate();
                        if (addedRows > 0) {
                            preparedStatement.execute();
                            JOptionPane.showMessageDialog(this, "Commissioned research for Allergy Project added correctly",
                                    "Congrate", JOptionPane.INFORMATION_MESSAGE);
                        }
                    }
                } else if (project.equals("Overweight")) {
                    //preparedStatement.execute();
                    commissionedresearch = VitaminD + " " + Glucose + " " + Insulin + " " + Thyroid + " " + Urinalysis + " " + BloodPressure + " " + Stresstest;
                    if (!cbVitaminD.isSelected() && !cbGlucose.isSelected() && !cbInsulin.isSelected() && !cbThyroid.isSelected() && !cbUrinalysis.isSelected() && !cbBloodPressure.isSelected() && !cbStressTest.isSelected()) {
                        JOptionPane.showMessageDialog(this, "Sorry, but first you need choose any of commissioned research",
                                "Unfortunately", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        PreparedStatement preparedStatement = connection.prepareStatement(sql);
                        preparedStatement.setString(1, commissionedresearch);
                        preparedStatement.setString(2, timeofresearch);
                        preparedStatement.setString(3, email);
                        int addedRows = preparedStatement.executeUpdate();
                        if (addedRows > 0) {
                            preparedStatement.execute();
                            JOptionPane.showMessageDialog(this, "Commissioned research for Overweight Project added correctly",
                                    "Congrate", JOptionPane.INFORMATION_MESSAGE);
                        }
                    }
                } else if (project.equals("Heart Attack")) {
                    //preparedStatement.execute();
                    commissionedresearch = Glucose + " " + Insulin + " " + ECG + " " + BloodPressure + " " + Holter + " " + Stresstest;
                    if (!cbGlucose.isSelected() && !cbInsulin.isSelected() && !cbECG.isSelected() && !cbBloodPressure.isSelected() && !cbHolter.isSelected() && !cbStressTest.isSelected()) {
                        JOptionPane.showMessageDialog(this, "Sorry, but first you need choose any of commissioned research",
                                "Unfortunately", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        PreparedStatement preparedStatement = connection.prepareStatement(sql);
                        preparedStatement.setString(1, commissionedresearch);
                        preparedStatement.setString(2, timeofresearch);
                        preparedStatement.setString(3, email);
                        int addedRows = preparedStatement.executeUpdate();
                        if (addedRows > 0) {
                            preparedStatement.execute();
                            JOptionPane.showMessageDialog(this, "Commissioned research for Heart Attack Project added correctly",
                                    "Congrate", JOptionPane.INFORMATION_MESSAGE);
                        }
                    }
                } else if (project.equals("Diabetes")) {
                    //preparedStatement.execute();
                    commissionedresearch = Glucose + " " + Insulin + " " + Thyroid + " " + Urinalysis + " " + BloodPressure + " " + Stresstest;
                    if (!cbGlucose.isSelected() && !cbInsulin.isSelected() && !cbThyroid.isSelected() && !cbUrinalysis.isSelected() && !cbBloodPressure.isSelected() && !cbStressTest.isSelected()) {
                        JOptionPane.showMessageDialog(this, "Sorry, but first you need choose any of commissioned research",
                                "Unfortunately", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        PreparedStatement preparedStatement = connection.prepareStatement(sql);
                        preparedStatement.setString(1, commissionedresearch);
                        preparedStatement.setString(2, timeofresearch);
                        preparedStatement.setString(3, email);
                        int addedRows = preparedStatement.executeUpdate();
                        if (addedRows > 0) {
                            preparedStatement.execute();
                            JOptionPane.showMessageDialog(this, "Commissioned research for Diabetes Project added correctly",
                                    "Congrate", JOptionPane.INFORMATION_MESSAGE);
                        }
                    }
                } else if (project.equals("Lung Cancer")) {
                    //preparedStatement.execute();
                    commissionedresearch = LungUltrasound + " " + LungXray + " " + Urinalysis + " " + BloodPressure + " " + Stresstest;
                    if (!cbLungUltrasound.isSelected() && !cbLungXray.isSelected() && !cbUrinalysis.isSelected() && !cbBloodPressure.isSelected() && !cbStressTest.isSelected()) {
                        JOptionPane.showMessageDialog(this, "Sorry, but first you need choose any of commissioned research",
                                "Unfortunately", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        PreparedStatement preparedStatement = connection.prepareStatement(sql);
                        preparedStatement.setString(1, commissionedresearch);
                        preparedStatement.setString(2, timeofresearch);
                        preparedStatement.setString(3, email);
                        int addedRows = preparedStatement.executeUpdate();
                        if (addedRows > 0) {
                            preparedStatement.execute();
                            JOptionPane.showMessageDialog(this, "Commissioned research for Lung Cancer Project added correctly",
                                    "Congrate", JOptionPane.INFORMATION_MESSAGE);
                        }
                    }
                }
    }catch (Exception e) {
                e.printStackTrace();
            }
    }

    private User searchemail(String email) {
        User user = null;
        final String DB_URL = "jdbc:mysql://localhost:3306/niadriana";
        final String USERNAME = "root";
        final String PASSWORD = "";
        try {
            //połączenie z bazą danych
            Connection connection = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            Statement statement = connection.createStatement();
            String sql = "SELECT * FROM users WHERE email=?";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, tfEmail.getText());
            ResultSet resultSet = preparedStatement.executeQuery();
            //dane które uzyskamy
            if (resultSet.next()) {
                String add1 = resultSet.getString("projects");
                tfProject.setText(add1);
                btnConfirm.setEnabled(true);
                //wybór i aktywacja badań w zależności od wybranego projektu
                if(add1.equals("Allergy")){
                    cbVitaminB12.setEnabled(true);
                    cbVitaminD.setEnabled(true);
                    cbGlucose.setEnabled(true);
                    cbInsulin.setEnabled(true);
                    cbUrinalysis.setEnabled(true);
                    cbBloodPressure.setEnabled(true);
                }else if(add1.equals("Overweight")){
                    cbVitaminD.setEnabled(true);
                    cbGlucose.setEnabled(true);
                    cbInsulin.setEnabled(true);
                    cbThyroid.setEnabled(true);
                    cbUrinalysis.setEnabled(true);
                    cbBloodPressure.setEnabled(true);
                    cbStressTest.setEnabled(true);
                }else if(add1.equals("Heart Attack")) {
                    cbGlucose.setEnabled(true);
                    cbInsulin.setEnabled(true);
                    cbECG.setEnabled(true);
                    cbBloodPressure.setEnabled(true);
                    cbHolter.setEnabled(true);
                    cbStressTest.setEnabled(true);
                }else if(add1.equals("Diabetes")){
                    cbGlucose.setEnabled(true);
                    cbInsulin.setEnabled(true);
                    cbThyroid.setEnabled(true);
                    cbUrinalysis.setEnabled(true);
                    cbBloodPressure.setEnabled(true);
                    cbStressTest.setEnabled(true);
                }else if(add1.equals("Lung Cancer")){
                    cbLungUltrasound.setEnabled(true);
                    cbLungXray.setEnabled(true);
                    cbUrinalysis.setEnabled(true);
                    cbBloodPressure.setEnabled(true);
                    cbStressTest.setEnabled(true);
                }
            }
            else{
                JOptionPane.showMessageDialog(this, "Email for searching is wrong, please enter correct email",
                        "Try one more time", JOptionPane.ERROR_MESSAGE);
            }
            statement.close();
            connection.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return user;
    }
    public void Calender() {
        Calendar calendar = new GregorianCalendar();
        int month = calendar.get(Calendar.MONTH);
        int year = calendar.get(Calendar.YEAR);
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        tfDate.setText(+day+"."+(month+1)+"."+year);
        //String date = tfDate.toString(+day+"."+(month+1)+"."+year);
    }
    /*public String Plan(){
        Calendar plan = new GregorianCalendar();
        int days = Integer.parseInt(tfTime.getText());
        int years = days / 365;
        int months = (days % 365) / 30;
        int Days = (days % 365) % 30;
        int YEARS = plan.get(Calendar.YEAR) + years;
        int MONTHS = plan.get(Calendar.MONTH) + months + 1;
        int DAYS = plan.get(Calendar.DAY_OF_MONTH) + Days;
        String timeofresearch = (String)(DAYS + "." + MONTHS + "." + YEARS);
        return timeofresearch;
    }*/
    public static void main(String[] args){
        CommissionedResearch_Form commissionedresearchform = new CommissionedResearch_Form();
    }
}
