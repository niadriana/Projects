import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class Research_Consent_Form extends JFrame {
    private JPanel ResearchConsentPanel;
    private JButton btnYes;
    private JButton btnNo;
    private JTextField tfEmail;
    private JButton btnSearchEmail;

    public Research_Consent_Form() {
        //parametry dla wyświetlanego okna zgody na badania i projekt badawczy
        setTitle("Research consent");
        setContentPane(ResearchConsentPanel);
        setMinimumSize(new Dimension(677, 200));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setVisible(true);

        //connectToDatabase();
        btnYes.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String consent = "YES";
                String email = tfEmail.getText();
                consentYES(email, consent);
                setVisible(false);
                //Profile_Form profileForm = new Profile_Form();
            }
        });

        btnNo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String consent = "NO";
                String email = tfEmail.getText();
                consentNO(email,consent);
                setVisible(false);
                //Profile_Form profileForm = new Profile_Form();
            }
        });
        btnSearchEmail.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String email = tfEmail.getText();
                buttonEnable(email);
            }
        });
    }

    private void consentYES(String email, String consent) {
            final String DB_URL = "jdbc:mysql://localhost:3306/niadriana";
            final String USERNAME = "root";
            final String PASSWORD = "";
            try {
                //sql oraz zmienne które są wymagane
                Connection connection = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
                String sql = "UPDATE users SET consent=? WHERE email=?";
                PreparedStatement preparedStatement = connection.prepareStatement(sql);
                preparedStatement.setString(1, consent);
                preparedStatement.setString(2, email);
                int addedRows = preparedStatement.executeUpdate();
                if (addedRows > 0) {
                    preparedStatement.execute();
                    JOptionPane.showMessageDialog(this, "Consent added correctly",
                            "Congrate", JOptionPane.INFORMATION_MESSAGE);
                }
            }catch(Exception e){
                e.printStackTrace();
            }
    }

    private void consentNO(String email, String consent) {
        final String DB_URL = "jdbc:mysql://localhost:3306/niadriana";
        final String USERNAME = "root";
        final String PASSWORD = "";
        try {
            //sql oraz zmienne które są wymagane
            Connection connection = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            String sql = "UPDATE users SET consent=?, projects=NULL, commissionedresearch=NULL, researchresults=NULL, timeofresearch=NULL WHERE email=?";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, consent);
            preparedStatement.setString(2, email);
            int addedRows = preparedStatement.executeUpdate();
            if (addedRows > 0) {
                preparedStatement.execute();
                JOptionPane.showMessageDialog(this, "No consent added correctly",
                        "Congrate", JOptionPane.INFORMATION_MESSAGE);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    private void buttonEnable(String email) {
        final String DB_URL = "jdbc:mysql://localhost:3306/niadriana";
        final String USERNAME = "root";
        final String PASSWORD = "";
        try {
            //połączenie z bazą danych
            Connection connection = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            Statement statement = connection.createStatement();
            String sql = "SELECT * FROM users WHERE email=?";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, tfEmail.getText());
            ResultSet resultSet = preparedStatement.executeQuery();
            //dane które uzyskamy
            if (resultSet.next()) {
                btnYes.setEnabled(true);
                btnNo.setEnabled(true);
            }
            else{
                JOptionPane.showMessageDialog(this, "Email for searching is wrong, please enter correct email",
                        "Try one more time", JOptionPane.ERROR_MESSAGE);
            }
            statement.close();
            connection.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /*private boolean connectToDatabase() {
        boolean hasConsent = false;
        final String MYSQL_SERVER_URL = "jdbc:mysql://localhost:3306/";
        final String DB_URL = "jdbc:mysql://localhost:3306/niadriana";
        final String USERNAME = "root";
        final String PASSWORD = "";
        //połączenie do MYSQLserver i stworzenie bazy danych (gdyby nie było)
        try {
            Connection connection = DriverManager.getConnection(MYSQL_SERVER_URL, USERNAME, PASSWORD);
            Statement statement = connection.createStatement();
            statement.executeUpdate("CREATE DATABASE IF NOT EXISTS niadriana");
            statement.close();
            connection.close();
            //połączenie z bazą danych i utworzenie tabeli, gdyby nie było
            connection = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            statement = connection.createStatement();
            String sql = "CREATE TABLE IF NOT EXISTS consent ("
                    + "id INT (10) NOT NULL PRIMARY KEY AUTO_INCREMENT, "
                    + "name VARCHAR (200) NOT NULL, "
                    + "surname VARCHAR(200) NOT NULL, "
                    + "consent VARCHAR(10) NOT NULL, "
                    + ")";
            statement.executeUpdate(sql);
            //sprawdzenie, czy już jest ktoś w bazie osób ze zgodą
            statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT COUNT(*) FROM consent");
            if(resultSet.next()) {
                int numUsers = resultSet.getInt(1);
                if(numUsers > 0) {
                    hasConsent = true;
                }
            }
            statement.close();
            connection.close();
        }
        catch(Exception e) {
            e.printStackTrace();
        }
        return hasConsent;
    }*/

    public static void main(String[] args) {
        Research_Consent_Form myResearchConsent = new Research_Consent_Form();
    }
}
